var changeColor=document.querySelector(".test")
changeColor.style.backgroundColor="#00ac01";